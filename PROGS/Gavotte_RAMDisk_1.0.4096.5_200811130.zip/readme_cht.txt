01. 驅動程序的配置信息存放在下面註冊表中：
　　HKLM\System\CurrentControlSet\Services\RRamdisk\Parameters\
　　為什麼要用 RRamdisk 這個名字，因為 XP SP1 開始內建了一個 Ramdisk 程式，
　　主要用於 XP Embbeded Edition 記憶體運行的。

02. 參數: DiskSizeM, DiskSizeK
　　以 M 和 K 為單位的虛擬磁碟大小，K 單位優先。

03. 參數: MediaType
　　虛擬磁碟模擬的磁碟類型：
　　　　1: RAMDisk (記憶體磁碟)
　　　　2: 固定裝置 (預設)
　　　　3: 可移除式裝置
　　　　4: 軟碟 (和"可移除式裝置"區別不大)

04. 參數: UsePAE
　　設為 1 時，允許在 32 位元 Windows 下使用 Memory Remap 到 4G 之上的記憶體。
　　要求 32 位元 2000/XP/Vista，4G 實體記憶體，BIOS 打開 Memory Remapping/Hole。

05. 參數: DriveLetter
　　所用磁碟機代號，預設為 R:

06. 參數: SectorsPerCluster
　　希望的簇大小, 若設成 0 則由驅動程序決定:
　　　　  2 M → FAT12, 簇=512
　　　　 32 M → FAT16, 簇=512
　　　　 64 M → FAT16, 簇=1k
　　　　128 M → FAT16, 簇=2k
　　　　256 M → FAT16, 簇=4k
　　　　512 M → FAT32, 簇=2k
　　　　 16 G → FAT32, 簇=4k
　　　　......
　　如果你選擇的簇大小比預設的小，分割區會被格式化成 FAT32 格式。

07. 參數: Image
　　由 rdutil 程序管理，主要用以自動加載 NTFS 映像檔。例如:
　　1.) 加載虛擬磁碟，不要做任何操作
　　2.) 格式化為 NTFS
　　　　　FORMAT /FS:NTFS /Q /V:RamDisk /A:512 R:
　　3.) 把 NTFS 的日誌大小設到最小（2M）
　　　　　CHKDSK /L:2048 R:
　　4.) 預設訪問權限（例子是只允許管理員們使用虛擬磁碟）
　　　　　CACLS R:\ /G: BUILTIN\Adminstrators:F
　　5.) 建立一些目錄結構，如臨時目錄
　　　　　MKDIR R:\TEMP
　　6.) 壓縮虛擬磁碟，並存到 registry 註冊表中
　　　　　rdutil R: registry

　　註:
　　1.) 盡量不要往虛擬磁碟上放太多東西，壓縮後的映像檔不能超過 64K
　　2.) 當你改變虛擬磁碟大小時必須重新建立映像檔
　　3.) 當映像檔大小和虛擬磁碟大小不符時，虛擬磁碟將不再自動格式化。
　　　　如果要驅動自動格式化，必須刪除這個註冊表項。

　　rdutil 程序使用示例:
　　1.) 備份註冊表裡的映像檔
　　　　　rdutil save filename
　　2.) 恢復註冊表裡的映像檔
　　　　　rdutil load filename
　　3.) 測試壓縮映像檔大小
　　　　　rdutil R:
　　　　　rdutil registry
　　　　　rdutil unpacked_file
　　　 第二條命令壓縮註冊表裡設置的預設磁碟機代號
　　　 第三條命令壓縮被解開的映像檔
　　4.) 壓縮磁碟機代號並存入註冊表
　　　　　rdutil R: registry
　　5.) 壓縮磁碟機代號但保存到檔案
　　　　　rdutil R: packed_file
　　6.) 把映像檔解開
　　　　　rdutil unpack packed_file unpacked_file
　　7.) 建立一個 NTFS 符號連接直接指向虛擬磁碟
　　　　　rdutil link temp \

08. 重新格式化虛擬磁碟
　　除了記憶體介質類型外，其它的磁碟機代號都可以重新格式化。如：
　　固定介質
　　　　FORMAT /FS:NTFS /FORCE /Q /V:RamDisk /A:512 R:
　　移動介質
　　　　ECHO Y | FORMAT /FS:NTFS /FORCE /Q /V:RamDisk /A:512 R:
　　你可以在開機腳本裡對虛擬磁碟重新格式化。但不推薦再次格式化為 FAT 分割區，
　　因為驅動程序格式化的分割區比通用格式化程序效率更高。如果要把虛擬磁碟做
　　成映像檔作它用 (特別是軟碟)，推薦重新格書化為標準格式。

09. Pagefile (虛擬記憶體檔案) 支援
　　如果你使用固定磁碟類型，並且不重新格式化，你可以用系統管理直接把
　　虛擬記憶體檔案加到虛擬磁碟上。若你使用其它磁碟類型，或需重新格式化，
　　請使用 addswap 程式建立虛擬記憶體檔案 (Pagefile)。 如：
　　　　addswap r:\pagefile.sys 16 32
　　建立一個虛擬記憶體檔案，最小 16 M，最大 32 M

10. TEMP 臨時目錄
　　驅動程序格式化時已經建立好了 TEMP 目錄。需要的話要
　　把 TEMP 和 TMP 環境變量設到子目錄下，不能設置到根目錄。

11. NTFS 符號連接到虛擬磁碟
　　當使用記憶體磁碟類型 (RAMDisk) 時，不能從其它 NTFS 分割區
　　建立符號連接到虛擬磁碟。固定裝置和可移除式裝置都沒有問題。

12. Connectix VirtualPC 兼容性
　　如果 VPC 無法使用實體 RAW 磁碟時，不要使用固定裝置類型。

13. 無磁碟機代號工作方式
　　把 DriveLetter 註冊表值設為空，驅動將不建立任何磁碟機代號。
　　注意不是刪除 DriveLetter，否則預設建立 R:。無磁碟機代號方式下，
　　用 rdutil 建立 RAM 目錄指向虛擬磁碟 (只能在 NTFS 分割區裡)：

　　　　rdutil link C:\ramdisk
　　　　　　連接 C:\ramdisk 到虛擬磁碟根目錄
　　　　rdutil link C:\TEMP TEMP
　　　　　　連接 C:\TEMP 到虛擬磁碟的 \TEMP 下
　　　　rmdir C:\ramdisk
　　　　　　rmdir 可以直接刪除連接點，不會影響連接目標
　　不推薦使用無磁碟機代號模式，
　　因為大多數防毒軟體無法實時監控無磁碟機代號的分割區

ChangeLog:
1.0.4096.5 通過卷標查看是否使用高記憶體
1.0.4096.5 修正部分ASUS主板兼容問題
1.0.4096.4 ?
1.0.4096.3 加強初始化清零
1.0.4096.2 ramdisk過大導致NTFS格式化映像檔無效
01.01.2008 support >=4G ram under 32bit windows
05.23.2007 x64 support
12.09.2003 fix SMP/HT compatibility
11.26.2003 fix re-format problem & some typo
11.25.2003 merge rdpack and rdj to rdutil
11.24.2003 add DiskSizeK registry, more compatible w/ antivirus software