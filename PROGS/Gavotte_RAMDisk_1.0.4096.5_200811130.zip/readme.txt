01. Parameters registry is
　　HKLM\System\CurrentControlSet\Services\RRamdisk\Parameters\
　　why RRamdisk, 'cause XP SP1 contain a Ramdisk driver for XP Embeded.

02. Parameter: DiskSizeM, DiskSizeK
　　your desired disk size, the unit is M bytes or K bytes. The DiskSizeK
　　has higher priority.

03. Parameter: MediaType
　　the reported drive type,
　　　　1: RAM Drive
　　　　2: Fixed Media (default)
　　　　3: Removable Media
　　　　4: Floppy Diskette

04. Parameter: DriveLetter
　　name say it is, default is R:

05. Parameter: SectorsPerCluster
　　your desired cluster size, zero for driver pickup:
　　　　2 M: FAT12, cluster=512
　　　 32 M: FAT16, cluster=512
　　　 64 M: FAT16, cluster=1k
　　　128 M: FAT16, cluster=2k
　　　256 M: FAT16, cluster=4k
　　　512 M: FAT32, cluster=2k
　　　 16 G: FAT32, cluster=4k
　　　......
　　you can specify smaller cluster size, force pre-format as FAT32

06. Parameter: Image
　　maintained by rdutil utlilty, mainly for preload NTFS image. eg:
　　1.) load ramdisk, don't write anything
　　2.) format the ramdisk
　　　　　FORMAT /FS:NTFS /Q /V:RamDisk /A:512 R:
　　3.) adjust logfile to minimum size
　　　　　CHKDSK /L:2048 R:
　　4.) reset access rights
　　　　　CACLS R:\ /G: BUILTIN\Adminstrators:F
　　5.) create necessary structure
　　　　　MKDIR R:\TEMP
　　6.) pack the disk image and save to registry
　　　　　rdutil R: registry

　　Notes:
　　1.) You should leave RamDisk as clean as possible before packing,
　　　　the max packed image size is 64K.
　　2.) The disk image only valid to same RamDisk size, you should
　　　　re-create disk image when size changed.
　　3.) The driver internal formater will disable if this registry present,
　　　　corrupt/size-mismatch value leave an un-formated disk.

　　rdutil utlility usage:
　　1.) backup registry image
　　　　　rdutil save filename
　　2.) restore registry image
　　　　　rdutil load filename
　　3.) report packed image size
　　　　　rdutil R:
　　　　　rdutil registry
　　　　　rdutil unpacked_file
　　　　　　second command reading DriveLetter from registry
　　　　　　the third is packing an unpacked image file
　　4.) packing image & save to registry
　　　　　rdutil R: registry
　　5.) packing image & save to file
　　　　　rdutil R: packed_file
　　6.) unpacking image
　　　　　rdutil unpack packed_file unpacked_file
　　7.) link NTFS junction to Ramdisk
　　　　　rdutil link temp \

07. Re-Format RamDisk
　 You can re-format RamDisk except RAMDrive media type. eg:
　 FixedMedia type
　　　 FORMAT /FS:NTFS /FORCE /Q /V:RamDisk /A:512 R:
　 RemovableMedia type
　　　 ECHO Y | FORMAT /FS:NTFS /FORCE /Q /V:RamDisk /A:512 R:
　 you can place your format command to startup script.
　 I don't recommend re-format to FAT, the pre-formated RamDisk is
　 more efficient than other format utililty.

08. pagefile support
　　you can set pagefile to FixMedia type disk w/ pre-formated system.
　　if you need other MediaType or re-format, use the addswap.exe utility:
　　　　addswap r:\pagefile.sys 16 32
　　create pagefile r:\pagefile.sys with min=16M max=32M.

09. TEMP directory
　　you should set TEMP/TMP directory to TEMP sub-directory,
　　don't use the root directory.

10. NTFS junction point to RAMDrive
　　You can't create NTFS junction point to RAMDrive media type,
　　Fixed & Removable Media type should work

11. Connectix VirtualPC compatibility
　　someone report problem with VirtualPC+physical volume/disk.
　　please set MediaType to RAMDrive/Removable.

12. Mountpoint without DriveLetter
　　Clear DriveLetter registry value will not create Drive Letter for Ramdisk.
　　Attn. Don't delete the DriveLetter registry, which fall to default R:.
　　You can setup mountpoint/junction linking to this unnamed Ramdisk.
　　　eg:
　　　　rdutil link C:\ramdisk
　　　　　　link C:\ramdisk to root of Ramdisk
　　　　rdutil link C:\TEMP TEMP
　　　　　　link C:\TEMP to \TEMP at Ramdisk
　　　　rmdir C:\ramdisk
　　　　　　rmdir can remove the link without clear target content
　　NoDriveLetter configuration isn't recommended, because most AntiVirus
　　software cannot realtime scan Volume w/o Drive Letter.

ChangeLog:
1.0.4096.5 通過卷標查看是否使用高內存
1.0.4096.5 修正部分ASUS主板兼容問題
1.0.4096.4
1.0.4096.3 加強初始化清零
1.0.4096.2 ramdisk過大導致NTFS格式化映像文件無效
01.01.2008 support >=4G ram under 32bit windows (UsePAE=1)
05.23.2007 x64 support
12.09.2003 fix SMP/HT compatibility
11.26.2003 fix re-format problem & some typo
11.25.2003 merge rdpack and rdj to rdutil
11.24.2003 add DiskSizeK registry, more compatible w/ antivirus software