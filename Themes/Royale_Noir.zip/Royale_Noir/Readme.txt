Copy the contents of this folder into your themes folder (for example: C:\Windows\resources\themes) 

Double click the RoyalNoir.msstyles file. 

From the "Color scheme:" drop down menu, you can select "Royale" (Also known as "Energy Blue", or simply "Media Center Style" 
is the theme from Windows XP Media Center Edition), or "Royale Noir" a leaked non-finalized dark variant of the "Royale" theme.

